import pygame
import sys

clock = pygame.time.Clock()

pygame.init()
x = 0
screen = pygame.display.set_mode((1600, 800))
r = pygame.Rect(50, 50, 100, 200)

# Название окна
pygame.display.set_caption("Python Rougelike")

# Иконка окна
icon = pygame.image.load("img/icon.png")
pygame.display.set_icon(icon)

# Бекграунд
backgraund = pygame.image.load("img/main-backgr.jpg")
backgraund2 = 0

# Для реализации прыжка
y = 300
is_jump = False
jump_count = 7

# Направление персонажа 
is_right = True  # Начинаем смотрящим вправо

# Анимация атаки влево 
attack_left = [
    pygame.image.load('img/player/attack_left/atk-left009.png'),
    pygame.image.load('img/player/attack_left/atk-left008.png'),
    pygame.image.load('img/player/attack_left/atk-left007.png'),
    pygame.image.load('img/player/attack_left/atk-left006.png'),
    pygame.image.load('img/player/attack_left/atk-left005.png'),
    pygame.image.load('img/player/attack_left/atk-left004.png'),
    pygame.image.load('img/player/attack_left/atk-left003.png'),
    pygame.image.load('img/player/attack_left/atk-left002.png'),
    pygame.image.load('img/player/attack_left/atk-left001.png'),
    pygame.image.load('img/player/attack_left/atk-left000.png')     
]

attack_right = [
    pygame.image.load('img/player/attack/atk-right000.png'),
    pygame.image.load('img/player/attack/atk-right001.png'),
    pygame.image.load('img/player/attack/atk-right002.png'),
    pygame.image.load('img/player/attack/atk-right003.png'),
    pygame.image.load('img/player/attack/atk-right004.png'),
    pygame.image.load('img/player/attack/atk-right005.png'),
    pygame.image.load('img/player/attack/atk-right006.png'),
    pygame.image.load('img/player/attack/atk-right007.png'),
    pygame.image.load('img/player/attack/atk-right008.png'),
    pygame.image.load('img/player/attack/atk-right009.png')     
]

walk_right = [
    pygame.image.load('img/player/walk/walk000.png'),
    pygame.image.load('img/player/walk/walk001.png'),
    pygame.image.load('img/player/walk/walk002.png'),
    pygame.image.load('img/player/walk/walk003.png'),
    pygame.image.load('img/player/walk/walk004.png'),
    pygame.image.load('img/player/walk/walk005.png'),
    pygame.image.load('img/player/walk/walk006.png'),
    pygame.image.load('img/player/walk/walk007.png'),
    pygame.image.load('img/player/walk/walk008.png'),
    pygame.image.load('img/player/walk/walk009.png')
]

walk_left = [
    pygame.image.load('img/player/walk_left/run-left009.png'),
    pygame.image.load('img/player/walk_left/run-left008.png'),
    pygame.image.load('img/player/walk_left/run-left007.png'),
    pygame.image.load('img/player/walk_left/run-left006.png'),
    pygame.image.load('img/player/walk_left/run-left005.png'),
    pygame.image.load('img/player/walk_left/run-left004.png'),
    pygame.image.load('img/player/walk_left/run-left003.png'),
    pygame.image.load('img/player/walk_left/run-left002.png'),
    pygame.image.load('img/player/walk_left/run-left001.png'),
    pygame.image.load('img/player/walk_left/run-left000.png')
]
idle_right = [
    pygame.image.load('img/player/idle/idle000.png'),
    pygame.image.load('img/player/idle/idle001.png'),
    pygame.image.load('img/player/idle/idle002.png'),
    pygame.image.load('img/player/idle/idle003.png'),
    pygame.image.load('img/player/idle/idle004.png'),
    pygame.image.load('img/player/idle/idle005.png'),
    pygame.image.load('img/player/idle/idle006.png'),
    pygame.image.load('img/player/idle/idle007.png'),
    pygame.image.load('img/player/idle/idle008.png'),
    pygame.image.load('img/player/idle/idle009.png')
]

idle_left = [
    pygame.image.load('img/player/idle/idle_left000.png'),
    pygame.image.load('img/player/idle/idle_left001.png'),
    pygame.image.load('img/player/idle/idle_left002.png'),
    pygame.image.load('img/player/idle/idle_left003.png'),
    pygame.image.load('img/player/idle/idle_left004.png'),
    pygame.image.load('img/player/idle/idle_left005.png'),
    pygame.image.load('img/player/idle/idle_left006.png'),
    pygame.image.load('img/player/idle/idle_left007.png'),
    pygame.image.load('img/player/idle/idle_left008.png'),
    pygame.image.load('img/player/idle/idle_left009.png')
]

player_anim = 0
myfont = pygame.font.Font('fonts/DeliciousHandrawn-Regular.ttf', 40)
myfont.get_linesize

while True:
    keys = pygame.key.get_pressed()
    # Смещение бекграунда
    var_anim = 0
    screen.blit(backgraund, (backgraund2 + 1600, 0))
    screen.blit(backgraund, (backgraund2, 0))
    if keys[pygame.K_a]:
        backgraund2 += 2
    if keys[pygame.K_d]:
        backgraund2 -= 2
    if backgraund2 == -1600:
        backgraund2 = 0
    
    # Атака с учетом направления 
    if keys[pygame.K_e]:
        if is_right:
            screen.blit(attack_right[player_anim], (x, y))
        else:
            screen.blit(attack_left[player_anim], (x, y))
        var_anim = 1
    
    # Обработка движения и idle анимации
    if keys[pygame.K_a] and var_anim == 0:
        screen.blit(walk_left[player_anim], (x, y))
        is_right = False
    elif keys[pygame.K_d] and var_anim == 0:
        screen.blit(walk_right[player_anim], (x, y))
        is_right = True
    else:
        # Idle анимация, если не атака и не движение
        if var_anim == 0:
            if is_right:
                screen.blit(idle_right[player_anim], (x, y))
            else:
                screen.blit(idle_left[player_anim], (x, y))

    # Передвижение с обновлением направления 
    if keys[pygame.K_a] and var_anim == 0:
        screen.blit(walk_left[player_anim], (x, y))
        is_right = False  # Обновляем направление
    elif keys[pygame.K_d] and var_anim == 0:
        screen.blit(walk_right[player_anim], (x, y))
        is_right = True   # Обновляем направление

    if keys[pygame.K_a]:
        x -= 25
    elif keys[pygame.K_d]:
        x += 25
    clock.tick(12)
    if player_anim == 9:
        player_anim = 0  
    else:
        player_anim += 1

    # Прыжок
    if not is_jump:
        if keys[pygame.K_SPACE]:
            is_jump = True
    else:
        if jump_count >= -7:
            if jump_count > 0:
                y -= (jump_count ** 2) / 2
            else:
                y += (jump_count ** 2) / 2
            jump_count -= 1
        else:
            is_jump = False
            jump_count = 7

    # Выход
    pygame.display.update()
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        pygame.display.flip()

    

    