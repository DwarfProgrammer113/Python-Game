import pygame
import sys

# Инициализация Pygame
pygame.init()

# Константы
SCREEN_WIDTH = 1600
SCREEN_HEIGHT = 800
FPS = 60
PLAYER_SPEED = 15  # Уменьшена скорость передвижения
JUMP_POWER = 100  # Уменьшена мощность прыжка
GRAVITY = 9.8  # Уменьшена гравитация
ANIMATION_SPEED = 0.25  # Коэффициент замедления анимации

# Настройка экрана
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Python Rougelike")
icon = pygame.image.load("img/icon.png")
pygame.display.set_icon(icon)


# Загрузка ресурсов
def load_images(path, count, reverse=False):
    images = [pygame.image.load(f'img/player/{path}{i:03d}.png') for i in range(count)]
    return images[::-1] if reverse else images


# Анимации персонажа
ANIMATIONS = {
    'idle_right': load_images('idle/idle', 10),
    'idle_left': load_images('idle/idle_left', 10),
    'walk_right': load_images('walk/walk', 10),
    'walk_left': load_images('walk_left/run-left', 10, reverse=True),
    'attack_right': load_images('attack/atk-right', 10),
    'attack_left': load_images('attack_left/atk-left', 10, reverse=True)
}

# Игровые объекты
player = {
    'x': 500,
    'y': 300,
    'anim_index': 0,
    'is_right': True,
    'is_jump': False,
    'jump_force': JUMP_POWER,
    'min_x': 400,
    'max_x': 600,
    'ground_y': 300,
    'anim_counter': 0  # Счетчик для замедления анимации
}

background = pygame.image.load("img/main-backgr.jpg")
background_offset = 0
animation_timer = pygame.time.Clock()


def handle_movement_fon():
    global background_offset
    keys = pygame.key.get_pressed()

    # Движение фона с уменьшенной скоростью
    if keys[pygame.K_a] and player['x']:
        background_offset += PLAYER_SPEED * 0.6

    if keys[pygame.K_d] and player['x']:
        background_offset -= PLAYER_SPEED * 0.6

    # Циклический сброс фона
    if background_offset >= SCREEN_WIDTH:
        background_offset -= SCREEN_WIDTH * 2
    elif background_offset <= -SCREEN_WIDTH:
        background_offset += SCREEN_WIDTH * 2


def handle_movement_player():
    keys = pygame.key.get_pressed()

    # Замедленное движение персонажа
    if keys[pygame.K_a] and player['x'] > player['min_x']:
        player['x'] -= PLAYER_SPEED * 0.2
        player['is_right'] = False

    if keys[pygame.K_d] and player['x'] < player['max_x']:
        player['x'] += PLAYER_SPEED * 0.2
        player['is_right'] = True


def handle_jump():
    if player['is_jump']:
        player['y'] -= player['jump_force'] * 0.2  # Замедленный прыжок
        player['jump_force'] -= GRAVITY

        if player['jump_force'] < -JUMP_POWER:
            player['is_jump'] = False
            player['y'] = player['ground_y']
            player['jump_force'] = JUMP_POWER


def get_current_animation():
    keys = pygame.key.get_pressed()

    if keys[pygame.K_e]:
        return 'attack_right' if player['is_right'] else 'attack_left'
    if keys[pygame.K_a]:
        return 'walk_left'
    if keys[pygame.K_d]:
        return 'walk_right'
    return 'idle_right' if player['is_right'] else 'idle_left'


# Главный игровой цикл
while True:
    screen.fill((0, 0, 0))

    # Отрисовка фона
    screen.blit(background, (background_offset - SCREEN_WIDTH, 0))
    screen.blit(background, (background_offset, 0))
    screen.blit(background, (background_offset + SCREEN_WIDTH, 0))

    # Обработка событий
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_w and not player['is_jump']:
                player['is_jump'] = True

    # Обновление состояния
    handle_movement_player()
    handle_movement_fon()
    handle_jump()

    # Замедление анимации
    player['anim_counter'] += ANIMATION_SPEED
    if player['anim_counter'] >= 1:
        player['anim_index'] = (player['anim_index'] + 1) % 10
        player['anim_counter'] = 0

    # Отрисовка персонажа
    current_anim = get_current_animation()
    screen.blit(ANIMATIONS[current_anim][player['anim_index']], (player['x'], player['y']))

    pygame.display.update()
    animation_timer.tick(FPS)