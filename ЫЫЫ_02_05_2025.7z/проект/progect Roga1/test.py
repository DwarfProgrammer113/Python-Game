
import pygame
import sys

pygame.init()

# Настройка экрана и начальные параметры
screen = pygame.display.set_mode((1600, 800))
pygame.display.set_caption("Python Rougelike")
icon = pygame.image.load("img/icon.png")
pygame.display.set_icon(icon)

clock = pygame.time.Clock()
background = pygame.image.load("img/main-backgr.jpg")
background_offset = 0

# Персонаж
x = 0
y = 300
is_jump = False
jump_count = 7
is_right = True

# Загрузка анимаций
def load_animation(path, count):
    return [pygame.image.load(f'{path}/{str(i).zfill(3)}.png') for i in range(count)]

walk_right = load_animation('walk', 'walk', 0, 9)
walk_left = load_animation('walk_left', 'run-left', 9, 0, -1)
attack_right = load_animation('attack', 'atk-right', 0, 9)
attack_left = load_animation('attack_left', 'atk-left', 9, 0, -1)
idle_right = load_animation('idle', 'idle', 0, 9)
idle_left = load_animation('idle', 'idle_left', 0, 9)

player_anim = 0

def update_background():
    global background_offset
    screen.blit(background, (background_offset + 1600, 0))
    screen.blit(background, (background_offset, 0))

    keys = pygame.key.get_pressed()
    if keys[pygame.K_a]:
        background_offset += 2
    if keys[pygame.K_d]:
        background_offset -= 2
    if background_offset == -1600:
        background_offset = 0

def handle_attack():
    global player_anim
    keys = pygame.key.get_pressed()
    if keys[pygame.K_e]:
        if is_right:
            screen.blit(attack_right[player_anim], (x, y))
        else:
            screen.blit(attack_left[player_anim], (x, y))
        return True
    return False

def handle_movement():
    global x, is_right, player_anim
    keys = pygame.key.get_pressed()
    if keys[pygame.K_a]:
        x -= 25
        is_right = False
        screen.blit(walk_left[player_anim], (x, y))
    elif keys[pygame.K_d]:
        x += 25
        is_right = True
        screen.blit(walk_right[player_anim], (x, y))
    else:
        # Отрисовка анимации простоя
        if is_right:
            screen.blit(idle_right[player_anim], (x, y))
        else:
            screen.blit(idle_left[player_anim], (x, y))

def animate_player():
    global player_anim
    player_anim += 1
    if player_anim >= 10:  # Ограничение по количеству кадров анимации
        player_anim = 0

def jump():
    global y, is_jump, jump_count
    keys = pygame.key.get_pressed()
    if not is_jump:
        if keys[pygame.K_SPACE]:
            is_jump = True
    else:
        if jump_count >= -7:
            y -= (jump_count ** 2) / 2 if jump_count > 0 else 0
            y += (jump_count ** 2) / 2 if jump_count < 0 else 0
            jump_count -= 1
        else:
            is_jump = False
            jump_count = 7

def main():
    global player_anim
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

        update_background()

        if not handle_attack():
            handle_movement()

        jump()
        animate_player()

        pygame.display.flip()
        clock.tick(12)

if __name__ == "__main__":
    main()